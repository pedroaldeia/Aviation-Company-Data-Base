from flask import Flask, request, jsonify
import psycopg
from psycopg.rows import namedtuple_row
from datetime import datetime, timedelta
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import os

app = Flask(__name__)
RATELIMIT_STORAGE_URI = os.environ.get("RATELIMIT_STORAGE_URI", "memory://")

app = Flask(__name__)
app.config.from_prefixed_env()
log = app.logger
limiter = Limiter(
    get_remote_address,
    app=app,
    default_limits=["200 per day", "50 per hour"],
    storage_uri=RATELIMIT_STORAGE_URI,
)

# Configuração da base de dados
DB_CONFIG = {
    'host': 'postgres',
    'dbname': 'aviacao',
    'user': 'aviacao',
    'password': 'aviacao'
}

def get_db_connection():
    try:
        conn = psycopg.connect(**DB_CONFIG, row_factory=namedtuple_row)
        return conn
    except psycopg.Error as e:
        print(f"Erro ao conectar à base de dados: {e}")
        return None

@app.route('/', methods=['GET'])
@limiter.limit("1 per second")
def listar_aeroportos():
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT nome, cidade FROM aeroporto ORDER BY cidade, nome")
                aeroportos = cur.fetchall()
        return jsonify(aeroportos)
    except Exception as e:
        return jsonify({'erro': str(e)}), 500

@app.route('/voos/<string:partida>/', methods=['GET'])
@limiter.limit("1 per second")
def listar_voos_partida(partida):
    try:
        partida = partida.upper()
        if len(partida) != 3:
            return jsonify({'erro': 'Código de aeroporto inválido'}), 400

        agora = datetime.now()
        limite = agora + timedelta(hours=12)

        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT v.no_serie, v.hora_partida, a_chegada.nome as aeroporto_chegada
                    FROM voo v
                    JOIN aeroporto a_chegada ON v.chegada = a_chegada.codigo
                    WHERE v.partida = %s AND v.hora_partida BETWEEN %s AND %s
                    ORDER BY v.hora_partida
                """, (partida, agora, limite))
                voos = cur.fetchall()

        return jsonify(voos)
    except Exception as e:
        return jsonify({'erro': str(e)}), 500

@app.route('/voos/<string:partida>/<string:chegada>/', methods=['GET'])
@limiter.limit("1 per second")
def proximos_voos_disponiveis(partida, chegada):
    try:
        partida = partida.upper()
        chegada = chegada.upper()

        if len(partida) != 3 or len(chegada) != 3:
            return jsonify({'erro': 'Códigos de aeroporto inválidos'}), 400

        agora = datetime.now()

        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    WITH capacidade_aviao AS (
                        SELECT no_serie, 
                               COUNT(CASE WHEN prim_classe THEN 1 END) as cap_primeira,
                               COUNT(CASE WHEN NOT prim_classe THEN 1 END) as cap_segunda
                        FROM assento 
                        GROUP BY no_serie
                    ),
                    bilhetes_vendidos AS (
                        SELECT v.id as voo_id,
                               COUNT(CASE WHEN b.prim_classe THEN 1 END) as vendidos_primeira,
                               COUNT(CASE WHEN NOT b.prim_classe THEN 1 END) as vendidos_segunda
                        FROM voo v
                        LEFT JOIN bilhete b ON v.id = b.voo_id
                        WHERE v.partida = %s AND v.chegada = %s AND v.hora_partida > %s
                        GROUP BY v.id
                    )
                    SELECT v.no_serie, v.hora_partida
                    FROM voo v
                    JOIN capacidade_aviao ca ON v.no_serie = ca.no_serie
                    LEFT JOIN bilhetes_vendidos bv ON v.id = bv.voo_id
                    WHERE v.partida = %s AND v.chegada = %s AND v.hora_partida > %s
                    AND (
                        COALESCE(bv.vendidos_primeira, 0) < ca.cap_primeira OR
                        COALESCE(bv.vendidos_segunda, 0) < ca.cap_segunda
                    )
                    ORDER BY v.hora_partida
                    LIMIT 3
                """, (partida, chegada, agora, partida, chegada, agora))
                voos = cur.fetchall()

        return jsonify(voos)
    except Exception as e:
        return jsonify({'erro': str(e)}), 500

@app.route('/compra/<int:voo>/', methods=['POST'])
def comprar_bilhetes(voo):
    try:
        nif_cliente = request.args.get('nif')
        bilhetes = request.json.get('bilhetes')

        if not nif_cliente or not bilhetes:
            return jsonify({'erro': 'NIF do cliente e lista de bilhetes são obrigatórios'}), 400
        for bilhete in bilhetes:
            if 'nome_passageiro' not in bilhete:
                return jsonify({'erro': 'Nome do passageiro é obrigatório'}), 400
            if "primeira_classe" not in bilhete:
                return jsonify({'erro': 'Classe do bilhete é obrigatória'}), 400

        if len(nif_cliente) != 9 or not nif_cliente.isdigit():
            return jsonify({'erro': 'NIF inválido'}), 400

        with get_db_connection() as conn:
            with conn.transaction():
                with conn.cursor() as cur:
                    cur.execute("SELECT no_serie FROM voo WHERE id = %s", (voo,))
                    no_serie = cur.fetchone()[0]
                    cur.execute("""
                        INSERT INTO venda (nif_cliente, balcao ,hora) 
                        VALUES (%s, NULL, NOW()) 
                        RETURNING codigo_reserva
                    """, (nif_cliente,))
                    codigo_reserva = cur.fetchone()[0]



                    for bilhete in bilhetes:
                        nome_passageiro = bilhete.get('nome_passageiro')
                        primeira_classe = bilhete.get('primeira_classe')


                        preco = 250.00 if primeira_classe else 100.00

                        cur.execute("""
                            INSERT INTO bilhete (voo_id, codigo_reserva, nome_passegeiro, preco, prim_classe, lugar, no_serie)
                            VALUES (%s, %s, %s, %s, %s, NULL, %s)
                        """, (voo, codigo_reserva, nome_passageiro, preco, primeira_classe, no_serie))

        return jsonify({
            'sucesso': True,
            'codigo_reserva': codigo_reserva,
            'mensagem': f'{len(bilhetes)} bilhete(s) comprado(s) com sucesso'
        })
    except Exception as e:
        return jsonify({'erro': str(e)}), 500

@app.route('/checkin/<int:bilhete>/', methods=['POST'])
def fazer_checkin(bilhete):
    try:
        with get_db_connection() as conn:
            with conn.transaction():
                with conn.cursor() as cur:

                    cur.execute("""
                        SELECT b.voo_id, b.no_serie, b.prim_classe, b.lugar
                        FROM bilhete b
                        WHERE b.id = %s
                    """, (bilhete,))
                    info = cur.fetchone()
                    voo_id =  info[0] if info else None
                    no_serie = info[1]
                    prim_classe = info[2]
                    lugar = info[3]
                    if lugar is not None:
                        return jsonify({'erro': 'Check-in já realizado'}), 400

                    if not voo_id:
                        return jsonify({'erro': 'Bilhete não encontrado'}), 404

                    cur.execute("""SELECT lugar
                        FROM assento a
                        WHERE a.no_serie = %s
                        AND a.prim_classe = %s
                        AND NOT EXISTS (
                            SELECT 1
                            FROM bilhete b
                            WHERE b.voo_id = %s
                                AND b.prim_classe = %s
                                AND b.lugar = a.lugar
                        )
                        ORDER BY CAST(REGEXP_REPLACE(lugar, '[A-Z]', '', 'g') AS INTEGER),  -- numeric row
                        REGEXP_REPLACE(lugar, '[0-9]', '', 'g')
                        LIMIT 1;""", (no_serie, prim_classe, voo_id, prim_classe))
                    
                    #return no_serie + str(prim_classe) + str(voo_id)
                    assento = cur.fetchone()[0]
                    #return "A"
                    """"""
                    if not assento:
                        return jsonify({'erro': 'Sem assento disponível'}), 400

                    cur.execute("""
                        UPDATE bilhete 
                        SET lugar = %s
                        WHERE id = %s
                    """, (assento, bilhete))

        return jsonify({
            'sucesso': True,
            'assento': assento,
            'mensagem': 'Check-in realizado com sucesso'
        })
    except Exception as e:
        return jsonify({'erros': str(e)}), 500


@app.errorhandler(404)
def not_found(error):
    return jsonify({'erro': 'Endpoint não encontrado'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'erro': 'Erro interno do servidor'}), 500

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=8080)

